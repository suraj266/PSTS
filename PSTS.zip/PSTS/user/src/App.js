import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Header } from './components/header/Header';
import Home from './components/home/Home';
import { MyProfile } from './components/myprofile/MyProfile';
import Stocks from './components/stocks/Stocks';
import TransactionHistory from './components/transactionHistory/TransactionHistory';

const Routing = () => {
  return (
    <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/Stocks' element={<Stocks />} />
      <Route path='/MyProfile' element={<MyProfile />} />
      <Route path='/TransactionHistory' element={<TransactionHistory />} />
    </Routes>
  )
}

function App() {
  return (
    <>
        <Router>
          <Header />
          <Routing />
        </Router>
    </>

  );
}

export default App;
