import * as React from 'react';
import Alert from '@mui/material/Alert';
import AlertTitle from '@mui/material/AlertTitle';
import Stack from '@mui/material/Stack';

export default function Toast(props) {
  return (
    <Stack sx={{ width: '100%' }} spacing={2}>
      <Alert severity={props.Type}>
        <AlertTitle>{props.Messege1}</AlertTitle>
        {props.Messege2}
      </Alert>
    </Stack>
  );
}
