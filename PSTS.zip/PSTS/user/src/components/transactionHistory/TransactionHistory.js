import * as React from 'react';
import { useEffect } from 'react';
import MUIDataTable from "mui-datatables";
export default function TransactionHistory() {

    const [stockrow, setStockrow] = React.useState([]);

    const columns = [
        { name: 'id', label: 'S.No', options: { filter: false, sort: true, } },
        { name: 'companyCode', label: 'company Code', width: 205, options: { filter: false, sort: true, } },
        { name: 'companyName', label: 'company Name', width: 205, options: { filter: true, sort: true, } },
        { name: 'currentPrice', label: 'current Price', width: 205, options: { filter: false, sort: true, } },
        { name: 'buyStock', label: 'buy Stock', width: 205, options: { filter: false, sort: true, } },
        { name: 'totalBuyPrice', label: 'total Buying Price', width: 205, options: { filter: false, sort: true, } },
        { name: 'sellStock', label: 'sell Stock', width: 205, options: { filter: false, sort: true, } },
        { name: 'totalSellPrice', label: 'total Selling Price', width: 205, options: { filter: false, sort: true, } },
        { name: 'comment', label: 'comment', width: 205, options: { filter: false, sort: false, } },
    ];

    const getStockData = async () => {
        try {
            const res = await fetch('http://localhost:5000/portfoliHistoryList', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + localStorage.getItem("token")
                },
            });
            const data = await res.json();
            setStockrow(data.transactionHistory);
            if (res.status === 400 || !data) {
                window.alert('No data Found')
            }
        } catch (err) {
            console.log(err);
        }
    }

    useEffect(() => {
        getStockData();
    }, [])

    const row = stockrow.map(({ companyCode, companyName, currentPrice, buyStock, totalBuyPrice, sellStock, totalSellPrice, comment }, index) => {
        return [
            index + 1,
            companyCode,
            companyName,
            currentPrice,
            buyStock,
            totalBuyPrice,
            sellStock,
            totalSellPrice,
            comment
        ]
    })

    return (
        <div style={{ height: 649, width: '100%' }}>
            <MUIDataTable
                title={"Transaction History"}
                data={row}
                columns={columns}
                options={{
                    selectableRows: 'none',
                }}
            />
        </div>
    );
}
