import * as React from 'react';
import { useEffect } from 'react';
import MUIDataTable from "mui-datatables";
import BuySellStocks from './BuySellStocks';
import { LoginForm } from '../loginForm/LoginForm'

export default function Stocks() {

    const [stockrow, setStockrow] = React.useState([]);

    const columns = [
        { name: 'id', label: 'S.No', options: { filter: false, sort: true, } },
        { name: 'companyCode', label: 'companyCode', width: 205, options: { filter: false, sort: true, } },
        { name: 'companyName', label: 'companyName', width: 205, options: { filter: true, sort: true, } },
        { name: 'currentPrice', label: 'currentPrice', width: 205, options: { filter: false, sort: true, } },
        { name: 'highPrice', label: 'highPrice', width: 205, options: { filter: false, sort: true, } },
        { name: 'lowPrice', label: 'lowPrice', width: 205, options: { filter: false, sort: true, } },
        { name: 'Action', label: 'Action', options: { filter: false, sort: true, } }
    ];

    const getStockData = async () => {
        try {
            const res = await fetch('http://localhost:5000/StockEvaluationList', {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + localStorage.getItem("token")
                },
            });
            const data = await res.json();
            setStockrow(data.data);
            if (res.status === 400 || !data) {
                window.alert('No data Found')
            }
        } catch (err) {
            console.log(err);
        }
    }

    useEffect(() => {
        getStockData();
    }, [])

    const row = stockrow.map(({ _id, companyCode, companyName, currentPrice, highPrice, lowPrice }, index) => {
        return [
            index + 1,
            companyCode,
            companyName,
            currentPrice,
            highPrice,
            lowPrice,
            <span>
                {localStorage.getItem("token") ?
                    <BuySellStocks StockData={{ _id, companyCode, companyName, currentPrice }} /> :
                    <LoginForm ButtonName='Login' />
                }
            </span>

        ]
    })

    return (
        <div style={{ height: 649, width: '100%' }}>
            <MUIDataTable
                title={"Stocks"}
                data={row}
                columns={columns}
                options={{
                    selectableRows: 'none',
                }}
            />
        </div>
    );
}
