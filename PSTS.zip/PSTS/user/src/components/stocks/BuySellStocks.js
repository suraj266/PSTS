import { Button, TextField, Typography } from '@mui/material';
import React, { useState } from 'react'
import Modal from '../Modal/Modal.components'
import BasicTabs from '../tabs/Tabs'
import TextareaAutosize from '@mui/base/TextareaAutosize';

export default function BuySellStocks(props) {
    const { _id, companyCode, companyName, currentPrice } = props.StockData;
    const [buyStock, setBuyStock] = useState(0);
    const [sellStock, setSellStock] = useState(0);
    const [open, setOpen] = useState(false);

    const [comment, setComment] = useState('');

 
    const [portfoliHistory, setPortfolioHistory] = useState({});

    let amount
    if (buyStock) {
        amount = portfoliHistory.VirtualAmount - (currentPrice * buyStock)
    } else {
        amount = portfoliHistory.VirtualAmount + (currentPrice * sellStock)
    }

    const handlePhistoryList = async () => {
        const res = await fetch('http://localhost:5000/portfoliHistoryList', {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("token")
            },
            body: JSON.stringify({
                companyId: _id
            })
        });
        const data = await res.json();
        setPortfolioHistory(data.Stock);
    }


    const handlePhistory = async () => {
        const res = await fetch('http://localhost:5000/PortfolioHistory', {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("token")
            },
            body: JSON.stringify({
                companyId: _id,
                companyCode,
                companyName,
                currentPrice,
                buyStock,
                totalBuyPrice: currentPrice * buyStock,
                sellStock,
                totalSellPrice: currentPrice * sellStock,
                comment
            })
        });
        await fetch('http://localhost:5000/UpdateVamount', {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("token")
            },
            body: JSON.stringify({
                VirtualAmount: amount
            })
        });
        const data = await res.json();
        setOpen(false)
        if (!data) {
            console.log("error in Buy/Sell Stocks");
        } else {
            handlePhistoryList();
            console.log('Stocks Buy/Sell Successfully...')
            setComment("");
            setBuyStock("");
            setSellStock("");
        }
    }

    return (
        <>
            <Modal
                // Style={{width:'500px'}}
                CompanyName={companyCode}
                open={open}
                setOpen={setOpen}
                handlePhistoryList={handlePhistoryList}
                modalContent={(
                    <BasicTabs
                        tabContent1={
                            <>
                                <Typography variant="h6" gutterBottom >
                                    Your PSTS Virtual Amount left is : <font color='green'>{portfoliHistory.VirtualAmount}</font>
                                </Typography>
                                <br />
                                <TextField onChange={e => { setBuyStock(e.target.value) }} id="outlined-basic" label="Enter Stoks" variant="outlined" />
                                <br /><br />
                                <Typography variant="h6" gutterBottom >
                                    Total buying price : <font color='blue'>{currentPrice * buyStock}</font>
                                </Typography>
                                <br />

                                {portfoliHistory.VirtualAmount >= currentPrice * buyStock ?
                                    (<>
                                        <TextareaAutosize
                                            aria-label="minimum height"
                                            minRows={6}
                                            maxRows={6}
                                            placeholder={`Please tell us why are you buying ${companyName} Stoks...`}
                                            style={{ width: 500 }}
                                            onChange={e => setComment(e.target.value)}
                                        />
                                        <div style={{ textAlign: 'center', marginTop: 20 }}>
                                            <Button
                                                variant="contained"
                                                color='success'
                                                onClick={() => {
                                                    handlePhistory();
                                                }}
                                            >Buy</Button>
                                        </div>
                                    </>
                                    ) :
                                    <div style={{ width: 505, height: 140 }}>
                                        <font color='red'><h3>you have insufficient amount...</h3></font>
                                    </div>
                                }

                            </>
                        }
                        tabContent2={
                            <>
                                <Typography variant="h6" gutterBottom >
                                    Total stock available : <font color='green'>{portfoliHistory.stockLeft}</font>
                                </Typography>
                                <br />
                                <TextField onChange={e => { setSellStock(e.target.value) }} id="outlined-basic" label="Enter Stoks" variant="outlined" />
                                <br /><br />
                                <Typography variant="h6" gutterBottom >
                                    Total selling price : <font color='blue'>{currentPrice * sellStock}</font>
                                </Typography>
                                <br />
                                {portfoliHistory.stockLeft >= sellStock ?
                                    (
                                        <>
                                            <TextareaAutosize
                                                minRows={6}
                                                maxRows={6}
                                                placeholder={`Please tell us why are you selling ${companyName} Stoks...`}
                                                style={{ width: 500 }}
                                                onChange={e => setComment(e.target.value)}
                                            />
                                            <div style={{ textAlign: 'center', marginTop: 20 }}>
                                                <Button
                                                    variant="contained"
                                                    color='secondary'
                                                    onClick={() => {
                                                        handlePhistory();
                                                    }}

                                                >Sell</Button>
                                            </div>
                                        </>
                                    ) :
                                    <div style={{ width: 505, height: 140 }}>
                                        <font color='red'><h3>you have insufficient Stoks...</h3></font>
                                    </div>
                                }
                            </>
                        }
                    />
                )}
            />
        </>
    )
}
