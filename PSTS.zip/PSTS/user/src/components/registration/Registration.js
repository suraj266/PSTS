import * as React from 'react';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { ThemeProvider } from '@mui/material/styles';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useTheme } from '@material-ui/core/styles';

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export function RegistrationForm() {
    const [open, setOpen] = React.useState(false);

    const [name, setName] = React.useState('');
    const [email, setEmail] = React.useState('');
    const [mobile, setMobile] = React.useState('');
    const [address, setAddress] = React.useState('');
    const [city, setCity] = React.useState('');
    const [state, setState] = React.useState('');
    const [pass, setPass] = React.useState('');
    const [Cpass, setCPass] = React.useState('');

    const theme = useTheme();
    const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

    const handleSubmit = async () => {
        if (pass === Cpass) {
            const res = await fetch('http://localhost:5000/Register', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    U_name: name,
                    U_email: email,
                    U_mobile: mobile,
                    U_address: address,
                    U_city: city,
                    U_state: state,
                    U_password: pass,
                    Cpassword: Cpass
                })
            })
            if (res) {
                toast.success('Registration Success', {
                    position: "top-center",
                    autoClose: 2000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: 'colored'
                });
                setOpen(false);
            }
        } else if (!name || !email || !mobile || !address || !city || !state || !pass || !Cpass) {
            toast.warning('All the fields are required', {
                position: "top-center",
                autoClose: 4000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: 'colored'
            });
        } else {
            toast.error('Password Not Match', {
                position: "top-center",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: 'colored'
            });
        }
    };

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    return (
        <div>
            <Button variant="text" color="primary" onClick={handleClickOpen}>
                Register
            </Button>
            <Dialog
                fullScreen={fullScreen}
                open={open}
                aria-labelledby="responsive-dialog-title"
            >

                <ThemeProvider theme={theme}>
                    <Container component="main" maxWidth="xs">
                        <CssBaseline />
                        <Box
                            sx={{
                                marginTop: 8,
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                            }}
                        >
                            <Typography component="h1" variant="h5">
                                Register
                            </Typography>
                            <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
                                <TextField
                                    onChange={e => setName(e.target.value)}
                                    margin="normal"
                                    required
                                    fullWidth
                                    id="name"
                                    label="Name"
                                    name="name"

                                />
                                <TextField
                                    value={email}
                                    onChange={e => { setEmail(e.target.value) }}
                                    margin="normal"
                                    required
                                    type="email"
                                    fullWidth
                                    id="email"
                                    label="Email Address"
                                    name="email"
                                />
                                <TextField
                                    value={mobile}
                                    onChange={e => {
                                        if (e.target.value.length === 11) {
                                            setMobile("")
                                        } else {
                                            setMobile(e.target.value)
                                        }
                                    }}
                                    margin="normal"
                                    required
                                    fullWidth
                                    type="number"
                                    id="mobile"
                                    label="Mobile Number"
                                    name="mobile"
                                    autoFocus
                                />
                                <TextField
                                    onChange={e => setAddress(e.target.value)}
                                    margin="normal"
                                    required
                                    fullWidth
                                    id="address"
                                    label="Address"
                                    name="address"
                                    autoFocus
                                />
                                <TextField
                                    onChange={e => setCity(e.target.value)}
                                    margin="normal"
                                    required
                                    fullWidth
                                    id="city"
                                    label="City Address"
                                    name="city"
                                    autoFocus
                                />
                                <TextField
                                    onChange={e => setState(e.target.value)}
                                    margin="normal"
                                    required
                                    fullWidth
                                    id="state"
                                    label="State Address"
                                    name="state"
                                    autoFocus
                                />
                                <TextField
                                    onChange={e => setPass(e.target.value)}
                                    margin="normal"
                                    required
                                    fullWidth
                                    name="password"
                                    label="Password"
                                    type="password"
                                    id="password"
                                />
                                <TextField
                                    onChange={e => setCPass(e.target.value)}
                                    margin="normal"
                                    required
                                    fullWidth
                                    name="cpassword"
                                    label="Confirm Password"
                                    type="password"
                                    id="password"
                                />
                                <Button
                                    onClick={() => handleSubmit()}
                                    fullWidth
                                    variant="contained"
                                    sx={{ mt: 3, mb: 2 }}
                                >
                                    Register
                                </Button>
                                <Grid container>
                                    <Grid item>
                                        <Link href="#" variant="body2">
                                            {"Don't have an account? Sign Up"}
                                        </Link>
                                    </Grid>
                                </Grid>
                            </Box>
                        </Box>
                    </Container>
                </ThemeProvider>

                <DialogActions>
                    <Button autoFocus onClick={handleClose} color="primary">
                        Cancel
                    </Button>
                </DialogActions>
            </Dialog>
            <ToastContainer />
        </div>
    );
}
