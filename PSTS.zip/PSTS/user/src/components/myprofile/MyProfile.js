import React, { useEffect } from 'react'
import './MyProfile.css'
import Divider from '@mui/material/Divider';

export const MyProfile = () => {

    const [userData, setUserData] = React.useState([]);


    const getUserData = async () => {
        try {
            const res = await fetch('http://localhost:5000/portfoliHistoryList', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + localStorage.getItem("token")
                },
            });
            const data = await res.json();
            setUserData(data.userData);
            if (res.status === 400 || !data) {
                window.alert('No data Found')
            }
        } catch (err) {
            console.log(err);
        }
    }

    useEffect(() => {
        getUserData();
    }, [])


    return (
        <>
            <div className='con-p-1'>
                <div className='con-p-11'> 
                    <img src='https://picsum.photos/id/1025/300/300' alt='myphoto' />
                </div>
                <div className='con-p-12'>
                    <div className='con-p-121'>
                        {userData.U_name}
                    </div>
                    <span>
                        <font color='#2F2E41'>Your PSTS Virtual Amount Left : </font><font color='green'>{userData.VirtualAmount}</font>
                    </span>
                    <Divider />
                    <div className='con-p-122'>
                        <table className='table'>
                            <tr><td>E-mail</td><td>{userData.U_email}</td></tr>
                            <tr><td>Mobile No.</td><td>{userData.U_mobile}</td></tr>
                            <tr><td>Address</td><td>{userData.U_address}</td></tr>
                            <tr><td>City</td><td>{userData.U_city}</td></tr>
                            <tr><td>State</td><td>{userData.U_state}</td></tr>
                        </table>
                    </div>
                </div>

            </div>
        </>
    )
}
