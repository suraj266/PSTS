import React from 'react';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useTheme } from '@material-ui/core/styles';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import { IconButton } from '@mui/material';
import ClearIcon from '@mui/icons-material/Clear';

export default function Modal(props) {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  const handleOpenModal = () => {
    props.setOpen(true)
    props.handlePhistoryList();
  }

  return (
    <div>
      <IconButton title='Buy Sell Stocks' onClick={() => handleOpenModal()}>
        <AddCircleOutlineIcon />
      </IconButton>

      <Dialog
        fullScreen={fullScreen}
        open={props.open}
        aria-labelledby="responsive-dialog-title"
      >
        <DialogActions>
          {props.CompanyName}
          <IconButton onClick={() => props.setOpen(false)}>
            <ClearIcon />
          </IconButton>
        </DialogActions>
        {props.modalContent}
      </Dialog>
    </div>
  );
}
