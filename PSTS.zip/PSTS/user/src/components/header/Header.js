import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { LoginForm } from '../loginForm/LoginForm';
import { RegistrationForm } from '../registration/Registration';
import { NavLink, useNavigate } from 'react-router-dom';
import { Button } from '@mui/material';

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    menuButton: {
        marginRight: theme.spacing(2),
    },
    header: {
        background: '#b9c1f9dd',
    },
    title: {
        flexGrow: 1,
        color: '#2F2E41'
    },
    logout: {
        color: '#2F2E41'
    }
}));

export function Header() {
    const classes = useStyles();
    const navigate = useNavigate();

    const handleLogOut = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("VAmount");
        navigate("/");
    }

    const RenderMenu = () => {
        if (localStorage.getItem("token")) {
            return (
                <>
                    <NavLink to='/' style={{ textDecoration: 'none', color: '#2F2E41' }}><Button color='inherit'>Home</Button></NavLink>
                    <NavLink to='/Stocks' style={{ textDecoration: 'none', color: '#2F2E41' }}><Button color='inherit'>Stocks</Button></NavLink>
                    <NavLink to='/TransactionHistory' style={{ textDecoration: 'none', color: '#2F2E41' }}><Button color='inherit'>Transaction History</Button></NavLink>
                    <NavLink to='/MyProfile' style={{ textDecoration: 'none', color: '#2F2E41' }}><Button color='inherit'>My Profile</Button></NavLink>
                    <Button color='primary' className={classes.logout} onClick={handleLogOut}><font className={classes.logout}>Logout</font></Button>
                </>
            )
        } else {
            return (
                <>
                    <NavLink to='/' style={{ textDecoration: 'none', color: '#2F2E41' }}><Button color='primary'>Home</Button></NavLink>
                    <NavLink to='/Stocks' style={{ textDecoration: 'none', color: '#2F2E41' }}><Button color='primary'>Stocks</Button></NavLink>
                    <LoginForm ButtonName='Login' ButtonColor='primary' />
                    <RegistrationForm />
                </>
            )
        }
    }


    return (
        <div className={classes.root}>
            <AppBar className={classes.header} position="static">
                <Toolbar>
                    <Typography variant="h6" className={classes.title}>
                        Trade & Learn
                    </Typography>
                    <RenderMenu />
                </Toolbar>
            </AppBar>
        </div>
    );
}
